#!/bin/sh
echo "Laderian Harris"
echo "Sopho,ore"
echo "ljharris42@tntech.edu"
:wq

